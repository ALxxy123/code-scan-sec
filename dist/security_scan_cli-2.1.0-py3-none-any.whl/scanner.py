import typer
import re
import os
import time
import json
import math
import google.generativeai as genai
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.progress import Progress
from datetime import datetime
import sys
import stat
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.text import Text

# --- Import AI Providers ---
from ai_providers.gemini_provider import GeminiProvider
from ai_providers.openai_provider import OpenAIProvider

# --- Initialization ---
console = Console()
app = typer.Typer(help="🛡️ AI-Powered Security Scanner by Ahmed Mubaraki 🛡️")

# --- Global Settings ---
OUTPUT_DIR = Path("output")
APP_CONFIG_DIR = Path.home() / ".security-scan"
RULES_FILE = APP_CONFIG_DIR / "rules.txt"
IGNORE_FILE = APP_CONFIG_DIR / "ignore.txt"
ENTROPY_THRESHOLD = 3.5

AI_PROVIDERS = {
    "gemini": GeminiProvider,
    "openai": OpenAIProvider,
}

DEFAULT_RULES = """
# Default Security Scan Rules
# Add your custom Regex patterns below
password\\s*[:=]\\s*['"][^'"]+['"];?
token\\s*[:=]\\s*['"][^'"]+['"];?
API_KEY\\s*[:=]\\s*['"][^'"]+['"];?
AKIA[0-9A-Z]{16}
AIza[0-9A-Za-z\\-_]{35}
ghp_[a-zA-Z0-9]{36}
"""

# ----------------------------------------------------------
# CONFIGURATION MANAGEMENT
# ----------------------------------------------------------

def initialize_config():
    """Create config directory and rule files if missing."""
    if not APP_CONFIG_DIR.exists():
        console.print(f"[yellow]First run detected. Creating config directory at: {APP_CONFIG_DIR}[/yellow]")
        APP_CONFIG_DIR.mkdir(parents=True)
    if not RULES_FILE.exists():
        console.print("[yellow]Creating default 'rules.txt'...[/yellow]")
        with open(RULES_FILE, "w") as f:
            f.write(DEFAULT_RULES)
    if not IGNORE_FILE.exists():
        console.print("[yellow]Creating empty 'ignore.txt'...[/yellow]")
        with open(IGNORE_FILE, "w") as f:
            f.write("# Add files or patterns to ignore, e.g.: *.log\n")


def load_rules() -> list[re.Pattern]:
    """Load regex rules from rules.txt."""
    if not RULES_FILE.exists():
        console.print(f"[bold red]Error: Missing rules file at {RULES_FILE}[/bold red]")
        console.print("Run [bold]'security-scan wizard'[/bold] to generate it.")
        sys.exit(1)

    with open(RULES_FILE, "r") as f:
        return [
            re.compile(line)
            for line in f.read().splitlines()
            if line.strip() and not line.strip().startswith("#")
        ]


def load_ignore_patterns() -> list[str]:
    """Load ignore patterns from ignore.txt."""
    if not IGNORE_FILE.exists():
        return []
    with open(IGNORE_FILE, "r") as f:
        return [
            p.strip()
            for p in f.read().splitlines()
            if p.strip() and not p.startswith("#")
        ]


# ----------------------------------------------------------
# HELPER FUNCTIONS
# ----------------------------------------------------------

def calculate_entropy(text: str) -> float:
    """Calculate Shannon entropy to detect randomness."""
    if not text:
        return 0.0
    probabilities = [text.count(c) / len(text) for c in set(text)]
    return -sum(p * math.log2(p) for p in probabilities if p > 0)


def extract_value_for_entropy(match_string: str) -> str:
    """Extract actual string value for entropy analysis."""
    quoted = re.search(r"['\"](.+?)['\"]", match_string)
    if quoted:
        return quoted.group(1)
    if "=" in match_string:
        parts = match_string.split("=", 1)
        if len(parts) > 1:
            return parts[1].strip()
    return match_string


# ----------------------------------------------------------
# REPORT GENERATION
# ----------------------------------------------------------

def write_json_report(findings: list, quiet: bool):
    path = OUTPUT_DIR / "results.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(findings, f, indent=4)
    if not quiet:
        console.print(f"JSON report generated: [green]{path}[/green]")


def write_md_report(findings: list, affected_files: int, quiet: bool):
    path = OUTPUT_DIR / "report.md"
    scan_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(path, "w", encoding="utf-8") as f:
        f.write("# 🛡️ Security Scan Report\n\n")
        f.write("## 📊 Summary\n")
        f.write(f"- **Total Findings:** {len(findings)}\n")
        f.write(f"- **Affected Files:** {affected_files}\n")
        f.write(f"- **Scan Date:** {scan_date}\n\n---\n\n")
        f.write("## 📄 Details\n\n")
        f.write("| File | Line | Rule | Match |\n")
        f.write("|------|------|------|-------|\n")
        for finding in findings:
            f.write(f"| `{finding['file']}` | {finding['line']} | `{finding['rule']}` | `{finding['match']}` |\n")
    if not quiet:
        console.print(f"Markdown report generated: [green]{path}[/green]")


def write_html_report(findings: list, affected_files: int, quiet: bool):
    path = OUTPUT_DIR / "report.html"
    scan_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rows = "\n".join(
        f"<tr><td><code>{f['file']}</code></td><td>{f['line']}</td><td><code>{f['rule']}</code></td><td><code>{f['match']}</code></td></tr>"
        for f in findings
    )
    html = f"""
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Security Scan Report</title>
<style>
body {{
    font-family: 'Segoe UI', Roboto, sans-serif; background: #f4f4f9; color: #333; margin: 2em;
}}
.container {{
    background: white; max-width: 1200px; margin: auto; padding: 2em;
    border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}}
h1, h2 {{ color: #2c3e50; }}
thead {{ background: #3498db; color: white; }}
th, td {{
    padding: 10px; border: 1px solid #ddd; word-break: break-all;
}}
tbody tr:nth-child(even) {{ background: #f9f9f9; }}
code {{
    background: #eee; padding: 2px 4px; border-radius: 4px;
}}
</style></head><body><div class="container">
<h1>🛡️ Security Scan Report</h1>
<h2>📊 Summary</h2>
<p>Total Findings: <b>{len(findings)}</b> &nbsp; | &nbsp; Affected Files: <b>{affected_files}</b> &nbsp; | &nbsp; Date: {scan_date}</p>
<h2>📄 Details</h2>
<table><thead><tr><th>File</th><th>Line</th><th>Rule</th><th>Match</th></tr></thead>
<tbody>{rows}</tbody></table>
</div></body></html>
"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    if not quiet:
        console.print(f"HTML report generated: [green]{path}[/green]")


# ----------------------------------------------------------
# CORE SCANNER LOGIC
# ----------------------------------------------------------

def run_scan(path: str, output: str, no_ai: bool, ai_provider: str, quiet: bool = False, from_hook: bool = False):
    """Main scanning workflow."""
    if not quiet:
        console.rule("[bold blue]Starting AI-Powered Security Scan[/bold blue]")
        console.print(f"Target Path: [cyan]{path}[/cyan]")

    OUTPUT_DIR.mkdir(exist_ok=True)

    ai_client = None
    if not no_ai:
        if ai_provider in AI_PROVIDERS:
            ProviderClass = AI_PROVIDERS[ai_provider]
            ai_client = ProviderClass()
            if not ai_client.initialize():
                ai_client = None
                no_ai = True
        else:
            console.print(f"[bold red]Unknown AI provider: {ai_provider}. AI disabled.[/bold red]")
            no_ai = True

    rules = load_rules()
    ignore_patterns = load_ignore_patterns()

    # --- File Discovery ---
    target = Path(path)
    all_files = [
        f for f in target.rglob("*")
        if f.is_file() and ".git" not in str(f) and "venv" not in str(f) and str(OUTPUT_DIR) not in str(f)
    ]

    if not quiet:
        console.print(f"Loaded [bold green]{len(rules)}[/bold green] rules.")
        console.print(f"Found [bold cyan]{len(all_files)}[/bold cyan] files to scan.\n")

    # --- Scanning Phase ---
    potential_findings = []
    for file_path in all_files:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    for rule in rules:
                        if match := rule.search(line):
                            potential_findings.append({
                                "file": str(file_path),
                                "line": line_num,
                                "match": match.group(0).strip(),
                                "rule": rule.pattern
                            })
                            break
        except Exception:
            continue

    if not potential_findings:
        console.print("[green]No matches found. Your code is clean! ✨[/green]")
        return

    # --- AI Verification ---
    findings_for_ai = []
    final_findings = []
    if not no_ai:
        console.print("\n[bold blue]Pre-filtering findings using entropy...[/bold blue]")
        for f in potential_findings:
            value = extract_value_for_entropy(f["match"])
            entropy = calculate_entropy(value)
            if entropy > ENTROPY_THRESHOLD:
                findings_for_ai.append(f)
                console.print(f"[yellow]High entropy ({entropy:.2f})[/yellow] -> queued for AI check.")
            else:
                console.print(f"[dim]Low entropy ({entropy:.2f}) -> ignored.[/dim]")

        console.print(f"\n[bold yellow]Verifying {len(findings_for_ai)} findings using {ai_provider}...[/bold yellow]")
        for finding in findings_for_ai:
            if ai_client.verify(finding["match"]):
                final_findings.append(finding)
    else:
        final_findings = potential_findings

    if not final_findings:
        console.print("[green]No verified secrets found![/green]")
        if from_hook:
            sys.exit(0)
        return

    # --- Display Results ---
    affected_files = len(set(f["file"] for f in final_findings))
    table = Table(title="AI-Verified Findings", show_header=True, header_style="bold magenta")
    table.add_column("File", style="cyan")
    table.add_column("Line", style="green")
    table.add_column("Rule", style="yellow")
    table.add_column("Match", style="red")
    for f in final_findings:
        table.add_row(f["file"], str(f["line"]), f["rule"], f["match"])
    console.print(table)

    # --- Output Reports ---
    if output and output != "none":
        console.print("\n[bold blue]Generating reports...[/bold blue]")
        if output in ["json", "all"]:
            write_json_report(final_findings, quiet)
        if output in ["md", "all"]:
            write_md_report(final_findings, affected_files, quiet)
        if output in ["html", "all"]:
            write_html_report(final_findings, affected_files, quiet)

    if from_hook:
        console.print("\n[bold red]COMMIT REJECTED: Secrets detected.[/bold red]")
        sys.exit(1)


# ----------------------------------------------------------
# CLI COMMANDS
# ----------------------------------------------------------

@app.command()
def scan(
    path: str = typer.Option(".", "--path", "-p", help="Path to the directory to scan."),
    output: str = typer.Option("none", "--output", "-o", help="Report format: json, md, html, all, none."),
    no_ai: bool = typer.Option(False, "--no-ai", help="Disable AI verification."),
    ai_provider: str = typer.Option("gemini", "--ai-provider", help="AI provider: gemini or openai."),
    from_hook: bool = typer.Option(False, hidden=True),
    quiet: bool = typer.Option(False, "--quiet", hidden=True)
):
    """Run a non-interactive scan (for CI/CD or hooks)."""
    initialize_config()
    run_scan(path, output, no_ai, ai_provider, quiet, from_hook)


@app.command()
def wizard():
    """Start the interactive guided scanning wizard."""
    while True:
        _print_welcome_banner()
        use_ai = Confirm.ask("Use AI verification to reduce false positives?", default=True)
        ai_provider = "gemini"
        if use_ai:
            ai_provider = Prompt.ask(
                "Select AI provider",
                choices=["gemini", "openai"],
                default="gemini"
            )
            key_name = f"{ai_provider.upper()}_API_KEY"
            api_key = Prompt.ask(f"Enter your {key_name}", password=True)
            os.environ[key_name] = api_key

        scan_path = Prompt.ask("Enter project path to scan", default=".")
        output_format = Prompt.ask(
            "Select report format",
            choices=["none", "json", "md", "html", "all"],
            default="none"
        )
        run_scan(scan_path, output_format, not use_ai, ai_provider)

        console.print("\n" + "=" * 80 + "\n")
        if not Confirm.ask("Run another scan?", default=True):
            console.print("[bold magenta]Goodbye! 👋[/bold magenta]")
            break


@app.command()
def install_hook(
    project_path: str = typer.Option(".", "--path", "-p", help="Path to the Git project.")
):
    """Install a pre-commit hook for automatic scans."""
    console.rule("[bold blue]Installing Git Pre-Commit Hook[/bold blue]")
    git_dir = Path(project_path) / ".git"
    if not git_dir.is_dir():
        console.print(f"[bold red]Error: '{git_dir}' is not a Git repository.[/bold red]")
        raise typer.Exit(1)

    hook_file = git_dir / "hooks" / "pre-commit"
    console.print(f"Target repository: [cyan]{git_dir.resolve()}[/cyan]")

    hook_content = """#!/bin/sh
# Security Scan Pre-Commit Hook

echo "--- Running Security Scan (Pre-Commit) ---"
export PATH="$HOME/.local/bin:$PATH"
security-scan scan --no-ai --from-hook

exit_code=$?
if [ $exit_code -ne 0 ]; then
    echo "----------------------------------------------"
    echo "COMMIT FAILED: Secrets found in your code."
    echo "----------------------------------------------"
    exit 1
else
    echo "--- Security Scan PASSED ---"
    exit 0
fi
"""

    try:
        if hook_file.exists():
            backup = hook_file.with_suffix(".bak")
            console.print(f"[yellow]Existing hook found. Backing up to {backup}[/yellow]")
            os.rename(hook_file, backup)

        with open(hook_file, "w") as f:
            f.write(hook_content)

        os.chmod(hook_file, os.stat(hook_file).st_mode | stat.S_IEXEC)
        console.print(f"[bold green]✅ Hook installed successfully: {hook_file}[/bold green]")
    except Exception as e:
        console.print(f"[bold red]Error installing hook: {e}[/bold red]")
        raise typer.Exit(1)


# ----------------------------------------------------------
# UTILITIES
# ----------------------------------------------------------

def _print_welcome_banner():
    console.clear()
    ascii_art = r"""
 ██████╗ ██████╗  █████╗ ███╗   ██╗███╗   ██╗███████╗██████╗ 
██╔════╝ ██╔══██╗██╔══██╗████╗  ██║████╗  ██║██╔════╝██╔══██╗
╚█████╗  ██████╔╝███████║██╔██╗ ██║██╔██╗ ██║█████╗  ██████╔╝
 ╚═══██╗ ██╔══██╗██╔══██║██║╚██╗██║██║╚██╗██║██╔══╝  ██╔══██╗
██████╔╝ ██║  ██║██║  ██║██║ ╚████║██║ ╚████║███████╗██║  ██║
╚═════╝  ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝
    """
    title = Text(ascii_art, style="bold magenta", justify="center")
    subtitle = Text("AI-POWERED SECURITY SCANNER", style="bold blue", justify="center")
    author = Text("\nDeveloped by Ahmed Mubaraki", style="dim italic", justify="center")
    panel = Panel(Text.assemble(title, "\n", subtitle, author), border_style="dim", padding=(1, 4))
    console.print(panel)
    with console.status("[bold green]Initializing engine...", spinner="dots8Bit"):
        initialize_config()
        time.sleep(1)
    console.print("\nThis wizard will guide you through scanning your project.\n")


if __name__ == "__main__":
    app()
